import importlib.metadata


__author__ = "Michael Dippery <michael@monkey-robot.com>"
__version__ = importlib.metadata.version("zscope")
