=====
zscope
=====

    Read text files from compressed archives in the terminal
