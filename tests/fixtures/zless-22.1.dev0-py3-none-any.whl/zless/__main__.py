import click


@click.command()
@click.argument("file")
def zless(file):
    click.echo(f"Hello, world! {file}")


if __name__ == "__main__":
    zless()
